module.exports = ({
  name: "fish collect",
  code: `$setGlobalUserVar[PezGlobo;$sum[$getGlobalUserVar[PezGlobo];$randomText[0;1;2;3;4;5;6;7;9;8;10]]]
  $setGlobalUserVar[PezPayaso;$sum[$getGlobalUserVar[PezPayaso];$randomText[0;1;2;3;4;5]]]
  $setGlobalUserVar[Salmon;$sum[$getGlobalUserVar[Salmon];$randomText[1;0;2;3;4;5;6;7;8]]]
  $setGlobalUserVar[Bacalao;$sum[$getGlobalUserVar[Bacalao];$randomText[0;1;3;2;4;5;6;7;8;9;10]]]
  $setGlobalUserVar[Fishhook;$replaceText[$replaceText[$getGlobalUserVar[Fishhook];true;$replaceText[$replaceText[$randomText[$getGlobalUserVar[Fishhook];false];false;true];true;false]];false;false]]
  $setGlobalUserVar[Fishroot;$sub[$getGlobalUserVar[Fishroot];$replaceText[$replaceText[$randomText[A;A;B];A;0];B;1]]]
  $addField[1;🎣 / Fuiste de pesca a;$randomText[una playa;un mar;un lago;un oceano];yes] 
 $addField[1;<a:bluearrow:897243209195982879> / Tiempo;$random[1;12]]
  $addField[1;<a:bluearrow:897243209195982879> / Peces Obtenidos;<:PezBacalao:946200958067679314> x$randomText[0;1;3;2;4;5;6;7;8;9;10]
<:PezSalmon:946201026128646144> x$randomText[1;0;2;3;4;5;6;7;8]
<:PezPayazo:946200450716287036> x$randomText[0;1;2;3;4;5]
<:PezGlobo:946200506810925116> x$randomText[0;1;2;3;4;5;6;7;9;8;10];yes]
  $addField[1;<a:bluearrow:897243209195982879> / Noticias de la Jornada;$replaceText[$replaceText[$randomText[A;A;B];A;- Su Caña de Pescar sigue en Perfecto estado];B;- Su Caña de Pescar se ha roto]
$replaceText[$replaceText[$getGlobalUserVar[Fishhook];true;$replaceText[$replaceText[$randomText[$getGlobalUserVar[Fishhook];false];false;- No ha perdido su Anzuelo];true;- Se han comido su anzuelo]];false;];no]
$color[1;RANDOM]
$globalCooldown[5m;Espera %time% para ir de pesca.]
$onlyIf[$getGlobalUserVar[Fishroot]>=1;No tienes un Caña de Pescar
Compra una para ir de pesca.]
`})