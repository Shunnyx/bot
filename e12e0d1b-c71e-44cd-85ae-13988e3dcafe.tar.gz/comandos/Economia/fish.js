module.exports = ({
name: "fish",
code: `Que quieres hacer?
**Collect** - Pescar
**Info** - Información de los peces y su probabilidad
`})