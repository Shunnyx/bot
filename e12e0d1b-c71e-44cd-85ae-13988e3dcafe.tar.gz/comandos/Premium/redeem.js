module.exports = ({
  name: "redeem",
  code: `
  $author[1;$username[$authorID]#$discriminator[$authorID];$authorAvatar]
 $description[1;**$customEmoji[Cowm9] Success:** <@$authorID> Felicidades ahora eres premium por 1 mes]
 $color[1;GREEN]
$setUserVar[premium;true;$authorID]
$setTimeout[30d;
userID: $authorID]
$onlyIf[$getUserVar[premium;$authorID]==false;**⛔ You have already redeemed a premium code**]
$argsCheck[>1;Please put a code!]
$onlyIf[$message==$getVar[code];Incorrect code or doesn't exist, please check that you had spelled the code correct, if you did, contact administration team to get this solved]`
}, {
  type: "timeout",
  code: `
 $sendDM[$timeoutData[userID];Your premium has just run out!]
 $setUserVar[premium;false;$timeoutData[userID]]`,
}) 
