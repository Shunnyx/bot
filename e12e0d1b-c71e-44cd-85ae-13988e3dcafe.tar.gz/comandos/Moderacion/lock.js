module.exports = ({
name: "lock",
code: `$title[1;🔒 Canal bloqueado]
$color[1;RANDOM]
$modifyChannelPerms[$guildID;$channelID;-sendmessage]
$onlyBotPerms[managechannel; permiso requerido: **MANAGECHANNEL**.]
$onlyPerms[managechannel;No tienes suficientes permisos. Permisos Faltantes: **MANAGECHANNEL**]
$thumbnail[1;$serverIcon]
$footer[1;Canal bloqueado por: $username#$discriminator]
$addTimestamp[1]`

}) 
