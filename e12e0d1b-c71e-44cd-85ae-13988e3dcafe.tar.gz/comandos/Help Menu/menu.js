module.exports = ({
  name: "menu",
  aliases: "commands",
  code: `
$title[1;Lista de comandos $username[$clientID]]
$description[1;
> **$username**
**$username[$ClientID]** Cuenta con [4]($getVar[support]) categorías y un total de [$commandsCount]($getVar[support]) comandos los cuales puedes usar en este servidor.

<:Mod9:986455783581577246> **Comandos de Moderación**
\`kick, ban, unban, poll, nuke, clear, lock, unlock, gstart, gw, gend, grerroll\`

<:Gears9:986455965463380099> **Comandos de Configuración**
\`set-prefix, add-cmd, cmd-list, delete-cmd\`

<:Info9:986456073219227678> **Comandos de Información**
\`avatar, botinfo, invite, ping\`

<:Economy9:986456221127180379> **Comandos de Economía**
\`work, crime, shop, deposit, withdraw, balance, weekly, daily, profile, set-desc, slut, leaderboard, buy, fish, mine\`

> :pencil: **Nota**
Si nesesitas ayuda adicional puedes entrar al servidor de [soporte]($getVar[support]) y tambien puedes [invitar]($getBotInvite) el bot a tu servidor.
]
$color[1;61DFFF]
$image[1;https://media.discordapp.net/attachments/753045490563547176/884434259987820594/LO2IzCa-1-1-1.gif]`
})