module.exports = ({
  name: "unban",
 code: `$unban[$message[1];$guildID]
 $title[1;¡Miembro no prohibido!]
 $description[1;<:Succes9:920475755408924713> <@$authorID> no prohibido <@$message[1]>]
 $color[1;GREEN]
 $onlyIf[$isBanned[$message[1];$guildID]==true;<:Succes9:920475755408924713> Este usuario no está prohibido]
 $onlyIf[$hasPerms[$guildID;$authorID;ban]==true;<:Error9:920475795208687668> No tienes permisos \`BAN\`]
 $onlyBotPerms[ban;<:Error9:920475795208687668> No tengo permisos \`BAN\`]`
})