module.exports = ({
 name: "add-cmd",
 code: `$setservervar[ccmd;$replacetext[$replacetext[$checkcondition[$getservervar[ccmd]!=];false;$tolowercase[$message[1]]/];true;$getservervar[ccmd]$tolowercase[$message[1]]/]]
$setservervar[cdes;$getservervar[cdes]$messageslice[1;10]/]
Echo agregado $replacetext[$replacetext[\`$tolowercase[$message[1]]\`;#right_click#;>];#left_click#;<] a la lista de comandos, escriba \`$getservervar[prefix]cmd-list\` para ver todos los comandos disponibles
$onlyif[$findtextsplitindex[$tolowercase[$message[1]]]==0;Comando \`$tolowercase[$message[1]]\` está disponible en la lista de comandos personalizados.]
$textsplit[$getservervar[ccmd];/]
$onlyif[$checkcontains[$message;#RIGHT#;#LEFT#;#RIGHT_BRACKET#;#LEFT_BRACKET#;/]==false;Por favor no uses \`símbolo\` trigger y respuesta]
$argscheck[>=2;**Uso Correcto** \n\`\`\`\n$getservervar[prefix]add-cmd <trigger> <respuesta>\`\`\`\]$onlyperms[admin;No tienes permisos para \`ADMIN\`]

`
})