module.exports = ({
name: "deposit", 
aliases: 'dep',
description: "Deposita tu dinero en el banco",
usage: "deposit",
category: "Economia",
code: `$setGlobalUserVar[banco;$sum[$getGlobalUserVar[banco;$authorID];$message];$authorID]
$setGlobalUserVar[monedas;$sub[$getGlobalUserVar[monedas;$authorID];$message];$authorID]
$thumbnail[1;$userAvatar[$authorID]]
$color[1;RANDOM]
$description[1;
> **$username,** \`Haz depositado $numberSeparator[$message] en tu banco!\`

> **Dinero**
> <a:coin:917454453462933536> \`$numberSeparator[$sub[$getGlobalUserVar[monedas;$authorID];$message]]\`
> **Banco**
> <a:coin:917454453462933536> \`$numberSeparator[$sum[$getGlobalUserVar[banco;$authorID];$message]]\`
> **Total**
> <a:coin:917454453462933536> \`$numberSeparator[$sum[$getGlobalUserVar[monedas;$authorID];$getGlobalUserVar[banco;$authorID]]]\`]
$onlyIf[$isNumber[$message[1]]==true;¡Eso no es un número!]
$onlyIf[$message<=$getGlobalUserVar[monedas;$authorID];¡No puedes depositar más de lo que tienes en tu monedero!]
$argsCheck[>=1;¿Cuanto estas depositando? Prueba esto: \`$getServerVar[prefix]dep <cantidad>\`]
$onlyIf[$getGlobalUserVar[monedas;$authorID]>0;¡No hay nada que depositar!]
$onlyIf[$truncate[$message]==$message;No pongas numeros decimales]
`
})