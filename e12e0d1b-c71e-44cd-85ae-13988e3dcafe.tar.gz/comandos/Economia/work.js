module.exports = ({
 name: "work",
 aliases: ["work"],
 code: `
$description[1;> **$username** \`trabajaste de $randomText[cocinero de Mcdonalds;peluquero/a;cajero en un centro comercial;obrero;minero;maestro/profesor;mesero;contador;pescador] y ganaste\` **+$random[10;350]** $getVar[coin]
]
$setGlobalUserVar[monedas; $sum[$getGlobalUserVar[monedas];$random[10;350]]]
$color[1;RANDOM]
$globalCooldown[20m;<a:IconNote:885245523592896552> <@$authorID> debes esperar %time% para volver a trabajar]

`
})