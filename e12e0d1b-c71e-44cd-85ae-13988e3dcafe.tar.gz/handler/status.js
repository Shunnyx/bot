module.exports = (bot) => {
	bot.status({
		text: ".menu 🌸",
		type: "PLAYING", 
		status: "online", 
		time: 6
	}) 
}