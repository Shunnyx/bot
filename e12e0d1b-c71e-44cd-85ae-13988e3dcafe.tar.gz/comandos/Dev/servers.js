module.exports = ({
  name: "servers",
  code: `
  $thumbnail[1;$userAvatar[$clientID]]
  $title[1;Servidores]
  $description[1;$serverNames[ **/** ]]
  $color[1;#00ddff]
  
$onlyForIDs[980955518401134633;**❌ | No Puedes Usar este comando **]`
})