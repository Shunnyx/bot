module.exports = ({
name: "setdesc",
aliases: ["setdescription", "set-desc"],
code: `$setGlobalUserVar[desc;$nomentionmessage]
$title[1;Descripción Actualizada]
$description[1;
**Descripción**:
$noMentionMessage]
$color[1;RANDOM]
$thumbnail[1;https://cdn.discordapp.com/attachments/933893784230559754/933893873170788382/Pencil9.png]
$footer[1;Para ver tu descripción usa $getServerVar[prefix]Profile]
$onlyIf[$charCount[$message]<=575;Tu descripción revaza los 575 caracteres (Cuenta con $charCount[$message]), Te recomiendo que la resumas]
$onlyIf[$toLowerCase[$getGlobalUserVar[desc]]!=$toLowerCase[$message];Ya tienes esa descripción!]
$argsCheck[>=1;**Agrega tu descripción!**]


`})