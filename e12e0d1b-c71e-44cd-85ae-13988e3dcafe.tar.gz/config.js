module.exports = {
	Bot: {
		token: "MTAyMDgxOTQ5NDgzMjE5NzYzMg.Gi3ls-.87fE4-DH5b-8k4u3OGrI-JoFcdPO2qSZVn8gn0",
		prefix: ".",
		intents: "all",
    }
  }
