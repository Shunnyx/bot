module.exports = ({
 name: "delete-cmd",
 code: `$setservervar[ccmd;$replacetext[$getservervar[ccmd];$advancedtextsplit[$getservervar[ccmd];/;$findtextsplitindex[$tolowercase[$message]]]/;]]
$setservervar[cdes;$replacetext[$getservervar[cdes];$advancedtextsplit[$getservervar[cdes];/;$findtextsplitindex[$tolowercase[$message]]]/;]]
Comando borrado con éxito $replacetext[$replacetext[\`$tolowercase[$message[1]]\`;#right_click#;>];#left_click#;<]
$onlyif[$findtextsplitindex[$tolowercase[$message]]!=0;Comando \`$tolowercase[$message]\` no disponible en la lista de comandos]
$textsplit[$getservervar[ccmd];/]
$onlyif[$checkcontains[$message;#RIGHT#;#LEFT#;#RIGHT_BRACKET#;#LEFT_BRACKET#;/]==false;por favor no lo uses \`simbolo\` para disparo y respuesta]
$argscheck[>=1;Uso correcto \n\`\`\`\n$getservervar[prefix]del-cmd <disparador>\n\`\`\`]
$onlyperms[admin;No tienes permisos \`ADMIN\`]
`
})