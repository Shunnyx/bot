
module.exports = ({
 name: "add-premium",
 code:
`$setGlobalUserVar[premium;false;$findUser[$message[1]]]
$channelSendMessage[$channelID;{newEmbed:{title::fuegolila: | Correcto} {description:$username[$findUser[$message[1]]]#$discriminator[$findUser[$message[1]]] premium activado} {color:GREEN}}]

$title[1;<:Premium9:922658418697830420> | ¡!]
$thumbnail[$mentioned[1]]
$description[1;**$username se activaron tus beneficios premium.**]

$addTimestamp[1]
$color[1;RANDOM]

$sendDM[$mentioned[1]]

$onlyIf[$message[1]!=;{newEmbed:{title::fuegoazul: | Error} {description:Debes mencionar a alguien} {color:RED}}]

$onlyForIDs[852694459375419452;{newEmbed:{title::fuegoazul: | Error} {description:Solo mi owner puede usar el comando pero si quieres premium lo puedes ganar en mi soporte ya sea en sorteos o en eventos} {color:RED}}]`

})