module.exports = ({
name: "unlock",
code: `$title[1;🔓 Canal desbloqueado]
$color[1;RANDOM]
$modifyChannelPerms[$guildID;$channelID;+sendmessage]
$onlyBotPerms[managechannel;:x_:┃No tengo el permiso: **MANAGE_CHANNEL**.]
$onlyPerms[managechannel;:x_:┃No tienes suficientes permisos. Permisos Faltantes: **MANAGE_CHANNEL**]
$thumbnail[1;$serverIcon]
$footer[1;Canal desbloqueado por: $username#$discriminator]
$addTimestamp[1]`
}) 