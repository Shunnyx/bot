module.exports = ({
  name: "bal",
  aliases: "balance",
  description: "Ver tu cantidad de dinero",
  usage: "crime",
  category: "Economia",
  cooldown: "No tiene",
  code: `
$thumbnail[1;$userAvatar[$mentioned[1]]]
$description[1;**Dinero**
> $getVar[coin] $numberSeparator[$getGlobalUserVar[monedas;$mentioned[1;yes]]]

**Banco**
> $getVar[coin]
$numberSeparator[$getGlobalUserVar[banco;$mentioned[1;yes]]]
]
$color[1;RANDOM]
`})