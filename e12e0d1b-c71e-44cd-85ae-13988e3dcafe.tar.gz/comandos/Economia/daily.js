module.exports = ({
 name: "daily",
 code: `
$description[1;> **$username** \`Recibiste\` **+$random[10;450]**$getVar[coin] \`de tu recompensa diaria\`
]
$setGlobalUserVar[monedas; $sum[$getGlobalUserVar[monedas];$random[10;450]]]
$color[1;RANDOM]
$globalCooldown[1d;<a:IconNote:885245523592896552> <@$authorID> debes esperar %time% para volver a recibitu recompensa diaria]
`})