module.exports = ({
name: "invite",
code: `$title[1;Invitacion de 9INE]
$description[1;Invita a 9INE a un servidor que sea de tu propiedad o uno que administres.
:white_small_square: [Invitar]($getBotInvite)
:white_small_square: [Soporte](https://discord.gg/pbwCdxChZU)
$color[1;RANDOM]`
})