module.exports = ({
name: "profile",
code: `$onlyIf[$isBot[$mentioned[1;yes]]!=true;**⛔ Los bots no tienen perfil**]
$thumbnail[1;$userAvatar[$mentioned[1;yes]]]
$title[1;$usertag[$mentioned[1]]]
$color[1;RANDOM]
$description[1; 
> <:Pencil9:940059030427168799> **Descripción**
\`\`\`diff
$getGlobalUserVar[desc;$mentioned[1;yes]]\`\`\`
> <:Economy9:920470063755169793> **Economia**
Dinero \`$numberSeparator[$getGlobalUserVar[monedas;$mentioned[1;yes]]]\`
Banco \`$numberSeparator[$getGlobalUserVar[banco;$mentioned[1;yes]]]\`
Total \`$sum[$getGlobalUserVar[monedas;$mentioned[1;yes]];$getGlobalUserVar[banco;$mentioned[1;yes]]]\`

> 🔺 **Nivel** \`$getGlobalUserVar[nivel;$mentioned[1]]\`
]`
})