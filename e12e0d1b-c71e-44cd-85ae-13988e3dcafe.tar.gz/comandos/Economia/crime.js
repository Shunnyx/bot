module.exports = ({
 name: "crime",
 description: "Comete un crimen y gana monedas.",
 usage: "crime",
 category: "Economia",
 cooldown: "20 Minutos",
 code: `
$description[1;> **$username** \`Robaste $randomText[a Mcdonalds;a discord;mi banco :c;el banco] y $replaceText[$replaceText[$randomText[+;-];+;Ganaste];-;Perdiste]\` **+$random[8;180]** $getVar[coin]
]
$setGlobalUserVar[monedas;$sum[$getGlobalUserVar[monedas];$randomText[+;-]$random[8;180]]]
$color[1;RANDOM]
$globalCooldown[20m;<a:IconNote:885245523592896552> <@$authorID> debes esperar %time% para volver a cometer un crimen]

`
})