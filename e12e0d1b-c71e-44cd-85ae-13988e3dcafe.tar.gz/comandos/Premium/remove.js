module.exports = ({
 name: "unpremium",
 code: `$setGlobalUserVar[premium;verdadero;$findUser[$message[1]]]
$channelSendMessage[$channelID;{newEmbed:{title::fuegolila: | Correcto} {description:$username[$findUser[$message[1]]]#$discriminator[$findUser[$message[1]]] Fue removido del premium} {color:GREEN}}]

$author[1;$username[$findUser[$noMentionMessage]]#$discriminator[$findUser[$noMentionMessage]]]
$image[1;$userAvatar[$findUser[$noMentionMessage]]]
$title[1;✅ | Usuario sacado del premium]
$description[1;🔰: Sacado por <@$authorID>.]

$addTimestamp[1]
$color[1;RANDOM]


$onlyIf[$message[1]!=;{newEmbed:{title::fuegoazul: | Error} {description:Debes mencionar a alguien} {color:RED}}]
$onlyForIDs[852694459375419452;{newEmbed:{title::fuegoazul: | Error} {description:Solo mi owner puede usar el comando pero si quieres premium lo puedes ganar en mi soporte ya sea en sorteos o en eventos} {color:RED}}]`
})
