module.exports = ({
  name: "clear",
  code: `
  **<:Succes9:920475755408924713> Se borraron $message mensajes.**
  $clear[$message]
  $deleteIn[5s]
  $onlyIf[$hasPerms[$guildID;$authorID;admin]==true;<:Error9:920475795208687668> No tienes permisos para hacer esto.]
  `
})