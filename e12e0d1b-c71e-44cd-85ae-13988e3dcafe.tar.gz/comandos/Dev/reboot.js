module.exports = ({
name: "reload",
aliases: "re",
description: "Reload all the commands! (Developer Only)",
usage: "reload",
code: 
`$addButton[1;Removido: $replaceText[$replaceText[$checkContains[$math[$get[oldcount]-$get[newcount]];-];true;0];false;$math[$get[oldcount]-$get[newcount]]];danger;removed;yes;:sparkling_stars:]
$addButton[1;Added: $replaceText[$replaceText[$checkContains[$math[$get[newcount]-$get[oldcount]];-];true;0];false;$math[$get[newcount]-$get[oldcount]]];success;added;yes;:sparkling_stars:]
$addButton[1;Actualizado: $get[newcount];primary;updated;yes;:sparkling_stars:]
$color[1;35CE8D]
$description[1;:shiningstars: **__Se ha recargado $commandsCount comandos correctamente.__**]
$deleteMessage[$get[reloadid];$channelID]
$wait[700ms]
$let[reloadid;$sendMessage[{newEmbed: {description::loading: **__Recargando todos los comandos.__**}{color:3ABEFF}};yes]]
$let[newcount;$commandsCount]
$updateCommands
$let[oldcount;$commandsCount]`
})