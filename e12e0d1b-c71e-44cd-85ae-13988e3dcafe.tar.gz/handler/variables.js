module.exports = (bot) => {
  bot.variables({
  prefix: ".",
  premium: "false",
  Dev: "false",
  //Economia//
  monedas: "0",
  desc: "Sin descripción.",
  banco: "0",
  dailychest: "0",
  weeklychest: "0",
  XP: "0",
 //Económia-items//
  plant: "0",
  chand: "0",
  lase: "0",
  gem11: "0",
  gem22: "0",
  trophy: "0",
  pickaxe: "0",
  gun: "0",
  lottery: "0",
  bag: "0",
  double: "0",
  joker: "0",
  ticket: "0",
  ////emotes///
  coin: "<:Coin9:984600733418680400>",
  support: "https://discord.gg/gky9SV4zs5",
  //Ecomomia-Tienda//
  Cookies: "0",
  Pickaxe: "0",
  Fishroot: "0",
  Torch: "false",
  Fishhook: "false",
//Economia-Pesca y mineria//
  Bacalao: "0",
  Salmon: "0",
  PezPayaso: "0",
  PezGlobo: "0",
  Hierro: "0",
  Cobre: "0",
  Oro: "0",
  Diamante: "0",
  Netherite: "0",
  //Comandos personalizados//
  ccmd: "",
  cdes: "",
  anounce: "",
//giveaways//
  date: "",
  host:"",
  win: "",
  prize: "",
  time: "",})
}