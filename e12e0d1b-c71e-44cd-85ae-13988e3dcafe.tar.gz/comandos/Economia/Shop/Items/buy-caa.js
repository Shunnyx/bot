module.exports = ({
  name: "buy caña",
  code: `$setGlobalUserVar[Fishroot;$sum[$getGlobalUserVar[Fishroot];1]]
  $setGlobalUserVar[monedas;$sub[$getGlobalUserVar[monedas];$multi[$message[2];50]]]
  $description[1;Compraste $message[2] cañas de pescar con el precio de 50;50]]
  $onlyIf[$replaceText[$ReplaceText[$noMentionMessage;+;];-;]==$noMentionMessage;No se aceptan numeros con + o -]
  $onlyIf[$multi[$message[2];50]<=$getGlobalUserVar[monedas];No tienes el dinero suficiente para comprar cañas de pescar]
`})