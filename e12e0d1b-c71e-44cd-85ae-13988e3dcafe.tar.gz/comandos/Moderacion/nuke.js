module.exports = ({
 name:"nuke",
 code:`$deleteChannel[$channelID]
$dm
$cloneChannel
$description[1;**Canal Nukeado Correctamente ✅**]
$onlyPerms[admin;**Usted no puede usar este comando!**]
$color[1;FDFEFE]`
}) 