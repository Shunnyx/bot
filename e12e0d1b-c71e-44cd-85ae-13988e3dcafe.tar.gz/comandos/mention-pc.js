module.exports = ({
name: "<@!$clientID>",
nonPrefixed: true,
code: `$description[1;$username El prefijo es \`$getServerVar[prefix]\` para ver la lista completa de comandos usa \`$getServerVar[prefix]menu\`]
$color[1;04dbfb]`
})  