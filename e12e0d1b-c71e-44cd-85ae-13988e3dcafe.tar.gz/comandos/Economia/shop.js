module.exports = ({
  name: "shop",
  aliases: "store",
  code: `$title[1;:shopping_bags: Tienda]
  $description[1;**$username** 
 Para comprar un item usa \`$getServerVar[prefix]buy-[Item/ID]\`

  **- Items**
:fishing_pole_and_fish: **Caña de pesca**
**ID** - **5**
**Valor** - $getVar[coin] **\`80\`**
**Descripción** - **Caña para ir de pesca.**

:pick: **Pica**
**ID** - **7**
**Valor** - $getVar[coin] **\`80\`**
**Descripción** - **Pica para ir a minar.**

— Pronto

<:NekoEgg9:970035372518174741> **Huevo de Neko**
**ID** - **8**
**Valor** - $getVar[coin] **\`2.500\`**
**Descripción** - **Huevo de mascota neko**

<:DinoEgg9:970035425601282158> **Huevo de Dinosaurio**
**ID** - **9**
**Valor** - $getVar[coin] **\`2.500\`**
**Descripción** - **Huevo de mascota dinosaurio**
]
$color[1;RANDOM]`
})