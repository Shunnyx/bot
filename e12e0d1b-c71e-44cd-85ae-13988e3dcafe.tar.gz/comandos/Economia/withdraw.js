module.exports = [{
  name: "withdraw",
  aliases: "with",
  code: `$setGlobalUserVar[banco;$sub[$getGlobalUserVar[banco];$nomentionMessage]]
  $setGlobalUserVar[monedas;$sum[$getGlobalUserVar[monedas];$nomentionMessage]]
  $description[1;\`Retiraste\` **$getGlobalUserVar[banco]** $description[1;> **$username** \`trabajaste de $randomText[cocinero de Mcdonalds;peluquero/a;cajero en un centro comercial;obrero;minero;maestro/profesor;mesero;contador;pescador] y ganaste\` **+$random[10;350]** $getVar[coin]
 \`de tu banco, utiliza\` **$getServerVar[prefix]bal** \`para ver tu dinero.\`]
  $color[1;RANDOM]
  $onlyIf[$replaceText[$ReplaceText[$noMentionMessage;+;];-;]==$noMentionMessage;No se aceptan numero con + o -]
  $onlyIf[$getGlobalUserVar[banco]>=$noMentionMessage;No tienes ese dinero]
  $onlyIf[$getGlobalUserVar[banco]!=0;No tienes dinero que retirar!]
  $onlyIf[$isNumber[$noMentionMessage]==true;Para depositar, puedes usar 1 de tres argumentos
< Numero > Depositas la cantidad indicada
All Depostas todo]
  $onlyIf[$toLowerCase[$message[1]]!=all]
  $onlyIf[$message[1]!=;Para depositar, puedes usar 1 de tres argumentos
< Numero > Depositas la cantidad indicada
All Depostas todo]
`},{
  name: "withdraw",
  aliases: "with",
  code: `
  $setGlobalUserVar[banco;$sub[$getGlobalUserVar[banco];$getGlobalUserVar[banco]]]
  $setGlobalUserVar[monedas;$sum[$getGlobalUserVar[monedas];$getGlobalUserVar[banco]]]
  $description[1;\`Retiraste\` **$getGlobalUserVar[banco]** $description[1;> **$username** \`trabajaste de $randomText[cocinero de Mcdonalds;peluquero/a;cajero en un centro comercial;obrero;minero;maestro/profesor;mesero;contador;pescador] y ganaste\` **+$random[10;350]** $getVar[coin]
 \`de tu banco, utiliza\` **$getServerVar[prefix]bal** \`para ver tu dinero.\`]
 $color[1;RANDOM]
 $onlyIf[$getGlobalUserVar[banco]!=0;No tienes dinero que retirar!]
$onlyIf[$toLowerCase[$message[1]]==all]
`}]