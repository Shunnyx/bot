module.exports = ({
name: "buy-michi",
aliases: "buy michi",
code: `
$setGlobalUserVar[badges;<:MichiInicial:934271328633114694>]
$thumbnail[1;$userAvatar[$authorID]]
$color[1;RANDOM]
$description[1; <:MichiInicial:934271328633114694> | **Has reclamado tu insignia usa 9!profile para verla.**
]`
})