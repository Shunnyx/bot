module.exports = ({
  name: "stats",
  aliases: "botinfo",
  code: `$title[1; Información de 9INE]
  $description[1;
> **[🌐 • General](https://discord.gg/pbwCdxChZU)**
> <:dev:842206590920163330> — **Desarrollador:** \`$usertag[852694459375419452]\`
> <:Support:840753717589442590> — **Ayudante:** No hay por el momento.

> **[📊 • Estadisticas](https://discord.gg/pbwCdxChZU)**
> <:server:895760824306643014> — **Servidores:** \`$serverCount\`
> 👤 — **Miembros:** \`$allMembersCount\`
> :control_knobs: — **Bot Ping:** \`$messageping\`
> :signal_strength: — **Api Ping:** \`$ping\`
> <:online:882420783304019999> — **Uptime:** \`$uptime\`

> **[ℹ️ • Informacion](https://discord.gg/pbwCdxChZU)**
> <a:diamond:879461485410123807> — **Version:** \`2.0.4\`
> 🆔 — **ID:** \`923674165532315718\`
> ❕ — **Comandos:** \`$commandsCount\`
> 📁 — **Categorias:** \`8\`
]
$color[1;RANDOM]`
})