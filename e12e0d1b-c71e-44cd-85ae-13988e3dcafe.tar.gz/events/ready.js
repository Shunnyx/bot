module.exports = (bot) => {
	bot.readyCommand({
		channel: "", 
		code: `$log[Ohayo.]`
	})
}
