module.exports = ({
  name: "buy pico",
  aliases: ["buy pica", "buy 7"],
  code: `$setGlobalUserVar[Pickaxe;$sum[$getGlobalUserVar[Pickaxe];1;]]
  $setGlobalUserVar[monedas;$sub[$getGlobalUserVar[monedas];$multi[$message[2];50]]]
  $description[1;Compraste Picos con el precio de 50;50]]
  $onlyIf[$replaceText[$ReplaceText[$noMentionMessage;+;];-;]==$noMentionMessage;No se aceptan numeros con + o -]
  $onlyIf[$multi[$message[2];50]<=$getGlobalUserVar[monedas];No tienes el dinero suficiente para comprar $message[2] Picos]
`})