module.exports = ({
  name: "mine info",
  aliases: "mine-info",
  code: `$title[1;Información de los minerales]
$addField[1;<:Netherite:914580146340651048> Netherite;Probabilidad 1/3
  Valor: 35;yes]
  $addField[1;<:Diamante:914426246547537950> Diamante;Probabilidad 1/5
  Valor: 25;yes]
  $addField[1;<:Oro:914426246245531648> Oro;Probabilidad: 1/7
  Valor: 20;yes]
  $addField[1;<:Hierro:914426246300057660> Hierro;Probabilidad: 1/10
  Valor: $10;yes]
  $addField[1;<:Cobre:914422836309917696> Cobre;Probabilidad: 1/12
  Valor: 5;yes]
  $color[1;RANDOM]
  $footer[1;Pueden salir 0 en todos]
`})