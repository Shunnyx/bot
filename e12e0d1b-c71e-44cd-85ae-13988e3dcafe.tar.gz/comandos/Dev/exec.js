module.exports = [{
  name: "exec",
  aliases: ['execute'],
  code: `$title[1;Comando ejeutado!]
  $addField[1;Resultado;$exec[$message];no]
  $addField[1;Tipo;$message[1];yes]
  $addField[1;Comando;$message;yes]
  $color[1;00ff00]
  $onlyForIDs[852694459375419452;868943195575312465;725432339227738124;**❌ | No Puedes Usar este comando **]`
  }]