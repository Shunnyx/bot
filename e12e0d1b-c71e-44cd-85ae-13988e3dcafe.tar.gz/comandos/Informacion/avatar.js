module.exports = ({
  name: "avatar",
  code: `$description[1;Avatar de <@$mentioned[1;yes]> 
  $image[1;$replaceText[$userAvatar[$findMember[$mentioned[1;yes]]];webp;png]]]
  $color[1;RANDOM]
  `
});