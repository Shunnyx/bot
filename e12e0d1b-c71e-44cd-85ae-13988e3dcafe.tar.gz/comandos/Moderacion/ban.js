module.exports = [{
 name:"ban",
 code: `$ban[$mentioned[1];$guildID;0;$if[$noMentionMessage==;No provisto;$noMentionMessage]]
 $title[1;<:Succes9:920475755408924713> Usuario baneado]
 $description[1;
 **Miembro:** <@$mentioned[1]>
 **Razon:** $if[$noMentionMessage==;No provisto;$noMentionMessage
 **Admin:** <@$authorID>]
 $color[1;RED]
 $onlyIf[$rolePosition[$highestRole[$authorID]]<$rolePosition[$highestRole[$mentioned[1]]];<:Error9:920475795208687668> No puedes prohibir a alguien con un rol más alto que tú.]
 $onlyIf[$highestRole[$mentioned[1]]!=$highestRole[$authorID];<:Error9:920475795208687668> No puedes prohibir a alguien con el mismo rol más alto.]
 $onlyIf[$rolePosition[$highestRole[$clientID]]<$rolePosition[$highestRole[$mentioned[1]]];<:Error9:920475795208687668> No puedo prohibir a alguien con un rol más alto que el mio.]
 $onlyIf[$highestRole[$mentioned[1]]!=$highestRole[$clientID];<:Error9:920475795208687668>No puedo prohibir a alguien con el mismo rol más alto que el mío]
 $onlyIf[$mentioned[1]!=$ownerID;<:Error9:920475795208687668> No puedes prohibir al propietario del servidor]
 $onlyIf[$mentioned[1]!=$authorID;<:Error9:920475795208687668> Estoy seguro de que no quieres hacer eso.]
 $onlyIf[$mentioned[1]!=$clientID;<:Error9:920475795208687668> No puedo prohibirme.]
 $onlyIf[$isMentioned[$mentioned[1]]==true;<:Error9:920475795208687668> Necesitas mencionar a alguien a quien quieres que prohíba]
 $onlyIf[$hasPerms[$guildID;$authorID;ban]==true;<:Error9:920475795208687668> No tienes permisos \`BAN\`]
 $onlyBotPerms[ban;<:Error9:920475795208687668> No tengo permisos \`BAN\`]`
}]