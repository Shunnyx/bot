module.exports = ({
    name: "set-prefix",
    aliases: ['setprefix'],
    code: `
$onlyIf[$getGlobalUserVar[premium]==true;❌ Este es un comando premium]

$setServerVar[prefix;$message[1]]
$description[1;<:Succes9:920475755408924713> El prefijo fue cambiado a \`$message[1]\`]
$color[1;RANDOM]
$argsCheck[>=1;**Escribe el nuevo prefijo!**]
$onlyPerms[admin;<:Error9:920475795208687668> Nesecitas \`ADMIN\` para cambiar el prefijo!]
`
   }) 