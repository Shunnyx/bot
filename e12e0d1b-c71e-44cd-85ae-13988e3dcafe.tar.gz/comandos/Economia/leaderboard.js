module.exports = ({
name: "leaderboard",
aliases: "lb",
code: `$title[1;Top Global de economia]
$addField[1;> Banco;$GlobalUserLeaderboard[banco;asc;**[{top} -](https://discord.gg/pbwCdxChZU)** {username} - {value}];yes]
$addField[1;> Dinero;$GlobalUserLeaderboard[monedas;asc;**[{top} -](https://discord.gg/pbwCdxChZU)** {username} - {value}];yes]
$color[1;RANDOM]
`})