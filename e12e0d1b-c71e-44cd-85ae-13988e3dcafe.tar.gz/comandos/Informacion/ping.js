module.exports = ({
    name: "ping",
    code: `:control_knobs: | **Bot:** $messageping
:signal_strength: | **Api:** $ping
🗃️ | **DataBase:** $dbPing
`
})