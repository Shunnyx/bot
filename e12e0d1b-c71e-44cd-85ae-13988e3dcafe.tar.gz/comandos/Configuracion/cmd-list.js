module.exports = ({
 name: "cmd-list",
 code: `$title[1;**__Comandos personalizados__**]
$color[1;RANDOM]
$thumbnail[1;$servericon]
$description[1;\`$replacetext[$replacetext[$replacetext[$getservervar[ccmd];#right_click#;>];#left_click#;<];/;, ]\`]
$addtimestamp[1]
$onlyif[$gettextsplitlength>=2;No hay comandos personalizados en el servidor. \`$servername\`]
$textsplit[$getservervar[ccmd];/]
`
})