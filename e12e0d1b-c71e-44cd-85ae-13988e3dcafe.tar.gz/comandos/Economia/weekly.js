module.exports = ({
 name: "weekly",
 code: `
$description[1;> **$username** \`Recibiste\` **+$random[10;550]**$getVar[coin] \`de tu recompensa semanal\`
]
$setGlobalUserVar[monedas; $sum[$getGlobalUserVar[monedas];$random[10;550]]]
$color[1;RANDOM]
$globalCooldown[1w;<a:IconNote:885245523592896552> <@$authorID> debes esperar %time% para volver a recibitu recompensa semanal]
`})