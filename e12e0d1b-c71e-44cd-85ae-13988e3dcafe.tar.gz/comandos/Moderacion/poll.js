module.exports = ({
name: "poll",
code: `$title[1;Votacion de $username]
$description[1;$message]
$color[1;RANDOM]
$footer[1;👍 Sí | 👎 No]
$addReactions[👎;👍]
$onlyIf[$message!=;Escribe algo!]
$onlyPerms[manageserver;admin;Necesitas el permiso de Gestionar Servidor!]
`})