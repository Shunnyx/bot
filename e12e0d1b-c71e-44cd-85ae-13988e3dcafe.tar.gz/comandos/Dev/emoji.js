module.exports = ({
 name: "emote",
 code:
 `
$description[1;
\`$customEmoji[$message]\`]`
})