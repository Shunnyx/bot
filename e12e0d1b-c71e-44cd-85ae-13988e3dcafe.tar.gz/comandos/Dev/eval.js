module.exports = ({
name: "eval",
code: `$eval[$message]
$onlyForIDs[852694459375419452;**❌ | No Puedes Usar este comando **]
`})