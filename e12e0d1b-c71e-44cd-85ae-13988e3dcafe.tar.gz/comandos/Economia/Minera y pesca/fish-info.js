module.exports = ({

  name: "fish info",
  code: `$title[1;Información de los pescados]
  $addField[1;<:PezGlobo:946200506810925116> Pez Globo;Probabilidad 1/10
  Valor: 5;yes]
  $addField[1;<:PezPayazo:946200450716287036> Pez Payaso;Probabilidad: 1/5
  Valor: 20;yes]
  $addField[1;<:PezSalmon:946201026128646144> Salmón;Probabilidad: 1/8
  Valor: 15;yes]
  $addField[1;<:PezBacalao:946200958067679314> Bacalao;Probabilidad: 1/10
  Valor: $10;yes]
  $color[1;RANDOM]
  $footer[1;Pueden salir 0 en todos]
`
})