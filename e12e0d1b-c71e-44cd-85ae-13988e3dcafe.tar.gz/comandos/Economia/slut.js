module.exports = ({
  name: "slut",
  code: `$setGlobalUserVar[monedas;$sum[$getGlobalUserVar[monedas];$replaceText[$replaceText[$randomText[A;B];A;+];B;-]$random[100;400]];$authorID]
  $addField[1;$replaceText[$replaceText[$randomText[A;B];A;Ganaste];B;Perdiste];$random[100;400] <a:Coin9:874780418778492989>;yes]
  $addField[1;Tiempo;$randomText[1 Hora;$random[2;12] Horas];yes]
  $addField[1;Trabajo;$randomText[Repartidor de Pizza;Influencer;Chofer];yes]
  $color[1;RANDOM]
$globalcooldown[5m;Debes esperar $replaceText[$replaceText[%time%;hours;Horas];minutes;Minutos]]
`})