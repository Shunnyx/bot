module.exports = ({
 name: "mine",
 code: `Que quieres hacer?
**Collect** - Minar
**Info** - Información de los minerales y su probabilidad]`
    })