module.exports = {
 name: "kick",
 code: `$kick[$mentioned[1];$guildID;$if[$noMentionMessage==;No provisto;$noMentionMessage]]
 $title[1;Miembro Expulsado!]
 $description[1;<@$authorID> expulsado <@$mentioned[1]>
 Razon: $if[$noMentionMessage==;No provisto;$noMentionMessage]
 $color[1;RED]
 $onlyIf[$rolePosition[$highestRole[$authorID]]<$rolePosition[$highestRole[$mentioned[1]]];No puedes expulsar a alguien con un rol más alto que tú]
 $onlyIf[$highestRole[$mentioned[1]]!=$highestRole[$authorID];No puedes expulsar a alguien con el mismo rol más alto]
 $onlyIf[$rolePosition[$highestRole[$clientID]]<$rolePosition[$highestRole[$mentioned[1]]];No puedo expulsar a alguien con un rol más alto que yo]
 $onlyIf[$highestRole[$mentioned[1]]!=$highestRole[$clientID];No puedo expulsar a alguien con el mismo rol más alto que el mío]
 $onlyIf[$mentioned[1]!=$ownerID;No puedes expulsar al dueño del servidor]
 $onlyIf[$mentioned[1]!=$authorID;Estoy seguro de que no quieres hacer eso]
 $onlyIf[$mentioned[1]!=$clientID;No puedo expulsarme]
 $onlyIf[$isMentioned[$mentioned[1]]==true;Necesitas mencionar a alguien a quien quieres expulsar]
 $onlyIf[$hasPerms[$guildID;$authorID;kick]==true;No tienes permisos de \`KICK\`]
 $onlyBotPerms[kick;No tengo permisos \`KICK\`]`
}