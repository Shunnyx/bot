module.exports = ({
  name: "help",
  code: `$title[Ayuda de $username[$clientID] 🌸]
$description[1;Hola <@$authorID> para ver todos mis comandos usa \`$getServerVar[prefix]menu\`]
  $addField[1;:heart: __**Invitarme**__;Si tienes un servidor o eres administrador puedes [invitarme](https://discord.com/api/oauth2/authorize?client_id=$clientID&permissions=8&scope=bot)]
  $addField[1;:gear: __**Reportar Bugs**__;Si encuentras un bug en el bot puedes usar el comando \`$getServerVar[prefix]report\` para reportarlo.]
$image[1;https://media.discordapp.net/attachments/732337957876269098/848140082527076392/3ca27c4810b8abce3fa6180b58c1e736.gif]
  $color[1;RANDOM]
`})