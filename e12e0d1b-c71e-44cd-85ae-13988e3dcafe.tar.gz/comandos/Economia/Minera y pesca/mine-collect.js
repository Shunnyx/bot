module.exports = ({
  name: "mine collect",
  aliases: "mine-collect",
  code: `
 $setGlobalUserVar[Oro;$sum[$getGlobalUserVar[Oro];$randomText[0;1;2;3;4;5;6;7;0;0;0]]]
  $setGlobalUserVar[Diamante;$sum[$getGlobalUserVar[Diamante];$randomText[1;0;2;3;4;5;0;0;0;0]]]

  $setGlobalUserVar[Hierro;$sum[$getGlobalUserVar[Hierro];$randomText[0;1;3;2;4;5;6;7;8;9;10;0]]]

  $setGlobalUserVar[Torch;$replaceText[$replaceText[$getGlobalUserVar[Torch];true;$replaceText[$replaceText[$randomText[$getGlobalUserVar[Torch];false];false;true];true;false]];false;false]]

  $setGlobalUserVar[Pickaxe;$sub[$getGlobalUserVar[Pickaxe];$replaceText[$replaceText[$randomText[A;A;B];A;0];B;1]]]

  $title[1;$username Fue a Minar!]

  $addField[1;Tiempo;$random[1;12] Horas]

  $addField[1;Minerales Obtenidos;<:MCcobre:946208564580589588> Cobre x$randomText[0;1;2;3;4;5;6;7;9;8;10;11;12]
<:MChierro:946210220852523068> Hierro x$randomText[0;1;3;2;4;5;6;7;8;9;10;0]
<:MCoro:946210516018282606> Oro x$randomText[0;1;2;3;4;5;6;7;0;0;0]
<:MCdiamante:946208612752175125> Diamante x$randomText[1;0;2;3;4;5;0;0;0;0]]

  $addField[1;Noticias de la Jornada;$replaceText[$replaceText[$randomText[A;A;B];A;- Su Pico sigue en Perfecto estado];B;- Su Pico se ha roto]
$replaceText[$replaceText[$getGlobalUserVar[Torch];true;$replaceText[$replaceText[$randomText[$getGlobalUserVar[Torch];false];false;- No se ha apagado su Antorcha];true;- Se ha apagado su Antorcha]];false;];no]
  $color[1;RANDOM]
  $thumbnail[1;https://static.wikia.nocookie.net/minecraft_gamepedia/images/7/7a/Diamond_Pickaxe_JE2_BE2.png/revision/latest?cb=20200217234128]
  $globalCooldown[8s;Espera %time%! Los minerales no son infinitos!]
$onlyIf[$getGlobalUserVar[Pickaxe]>=1;No tienes un Pico para poder Minar!]


`})